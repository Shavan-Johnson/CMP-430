package com.example.exerciseseetings;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

public class Settings extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    private String spinnerLabel = "";
    private SharedPreferences mPreferences;
    private String sharedPrefFile = "com.example.exerciseseetings";
    SharedPreferences.Editor preferencesEditor;
    private int mColor;
    private ConstraintLayout constraintLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        constraintLayout = findViewById(R.id.cl);
        Spinner sSpinner = findViewById(R.id.spinner);
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        preferencesEditor = mPreferences.edit();
        mColor = mPreferences.getInt("light", mColor);
        constraintLayout.setBackgroundResource(mColor);

        if (sSpinner != null) {
            sSpinner.setOnItemSelectedListener(this);
        }
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.theme_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource
                (android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner.
        if (sSpinner != null) {
            sSpinner.setAdapter(adapter);
        }
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        spinnerLabel = parent.getItemAtPosition(position).toString();
        choose();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    @SuppressLint("ResourceType")
    private void choose() {

        int j = 0;
        switch (spinnerLabel) {
            case "Light":
                j = ContextCompat.getColor(this, R.color.white);
                break;
            case "Dark":
                j = ContextCompat.getColor(this, R.color.black);
                break;
        }

        preferencesEditor.putInt("light", j);
        //preferencesEditor.putInt("winner", i);
        preferencesEditor.apply();
    }
    public void startTimer() {
        Intent intent = new Intent(this, TimerActivity.class);
        startActivity(intent);
    }
}
