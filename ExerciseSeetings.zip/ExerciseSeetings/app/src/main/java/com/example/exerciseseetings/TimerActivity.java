package com.example.exerciseseetings;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.os.Handler;
import java.util.Locale;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class TimerActivity extends AppCompatActivity {
    private NotificationManager mNotifyManager;
    private static final String ACTION_UPDATE_NOTIFICATION =
            "com.android.example.notifyme.ACTION_UPDATE_NOTIFICATION";
    // Notification channel ID.
    private static final String PRIMARY_CHANNEL_ID =
            "primary_notification_channel";
    // Notification ID.
    private static final int NOTIFICATION_ID = 0;
    private TextView timerView;
    private static final String LOG_TAG = TimerActivity.class.getSimpleName();
    private boolean isRunning;
    private boolean stoppedRunning;
    private int seconds = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timer_activity);
        timerView = (TextView) findViewById(R.id.timer_view);
        createNotificationChannel();
        if (savedInstanceState != null) {
            seconds = savedInstanceState.getInt("seconds");
            stoppedRunning = savedInstanceState.getBoolean("wasRunning");
            isRunning = savedInstanceState.getBoolean("isRunning");
        }
        runTimer();
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("Seconds", seconds);
        savedInstanceState.putBoolean("Is Running", isRunning);
        savedInstanceState.putBoolean("Stopped Running", stoppedRunning);

    }

    public void createNotificationChannel() {

        // Create a notification manager object.
        mNotifyManager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // Notification channels are only available in OREO and higher.
        // So, add a check on SDK version.
        if (android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.O) {

            // Create the NotificationChannel with all the parameters.
            NotificationChannel notificationChannel = new NotificationChannel
                    (PRIMARY_CHANNEL_ID,
                            getString(R.string.notification_channel_name),
                            NotificationManager.IMPORTANCE_HIGH);
            mNotifyManager.createNotificationChannel(notificationChannel);
        }
    }
    private NotificationCompat.Builder getNotificationBuilder() {

        // Set up the pending intent that is delivered when the notification
        // is clicked.
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent notificationPendingIntent = PendingIntent.getActivity
                (this, NOTIFICATION_ID, notificationIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT);

        // Build the notification with all of the parameters.
        NotificationCompat.Builder notifyBuilder = new NotificationCompat
                .Builder(this, PRIMARY_CHANNEL_ID)
                .setContentTitle("Finished Exercising")
                .setContentText("You have exercised for " + seconds + " seconds!")
                .setAutoCancel(true).setContentIntent(notificationPendingIntent)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL);
        return notifyBuilder;
    }

    @Override
    protected void onPause() {
        super.onPause();
        stoppedRunning = isRunning;
        isRunning = false;
        Log.d(LOG_TAG, "onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (stoppedRunning == true) {
            isRunning = true;
        }
        Log.d(LOG_TAG, "onResume");

    }
    @Override
    public void onStart(){
        super.onStart();
        Log.d(LOG_TAG, "onStart");
    }
    @Override
    public void onRestart(){
        super.onRestart();
        Log.d(LOG_TAG, "onRestart");
    }
    @Override
    public void onStop(){
        super.onStop();
        Log.d(LOG_TAG, "onStop");
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(LOG_TAG, "onDestroy");
    }
    public void onClickStart(View view) {
        isRunning = true;
    }
    public void onClickRestart(View view) {
        seconds = 0;
        isRunning = false;
    }
    public void onClickStop(View view) {
        isRunning = false;
        NotificationCompat.Builder notifyBuilder = getNotificationBuilder();
        mNotifyManager.notify(NOTIFICATION_ID, notifyBuilder.build());
    }
    private void runTimer() {
        Handler handle = new Handler();
        handle.post(new Runnable() {
            @Override
            public void run() {
                int hrs = seconds / 3600;
                int mins = (seconds % 3600) / 60;
                int secs = seconds % 60;
                String timeCount = String.format(Locale.getDefault(), "%d:%02d:%02d", hrs, mins, secs);
                timerView.setText(timeCount);
                if (isRunning == true) {
                    seconds++;
                }
                handle.postDelayed(this, 1000);
            }
        });
    }
}
