package com.example.scorecounter;

//https://youtu.be/yKURGZdZ3i8

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    public static final String EXTRA_MESSAGE =
            "com.example.android.twoactivities.extra.MESSAGE";
    private int mCount1 = 0;
    private int mCount2 = 0;

    private TextView mShowCount1;
    private TextView mShowCount2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(LOG_TAG, "-------");
        Log.d(LOG_TAG, "onCreate");

        mShowCount1 = (TextView) findViewById(R.id.show_count1);
        mShowCount2 = (TextView) findViewById(R.id.show_count2);
    }

    public void countUp1(View view) {
        mCount1++;
        if (mShowCount1 != null) {
            mShowCount1.setText(Integer.toString(mCount1));
        }
        if(mCount1 == 5) {
            Intent intent = new Intent(this, WinnerActivity.class);
            int points = (mCount1 - mCount2);
            String message = "Team 1 has won by " + points + " point";
            if(points > 1) {
                message = message + "s!";
            }
            else {
                message = message + "!";
            }
            intent.putExtra(EXTRA_MESSAGE, message);
            startActivity(intent);
        }
    }

    public void countUp2(View view) {
        mCount2++;
        if (mShowCount2 != null) {
            mShowCount2.setText(Integer.toString(mCount2));
        }
        if(mCount2 == 5) {
            Intent intent = new Intent(this, WinnerActivity.class);
            int points = (mCount2 - mCount1);
            String message = "Team 2 has won by " + points + " point";
            if(points > 1) {
                message = message + "s!";
            }
            else {
                message = message + "!";
            }
            intent.putExtra(EXTRA_MESSAGE, message);
            startActivity(intent);
        }
    }
    @Override
    public void onPause(){
        super.onPause();
        Log.d(LOG_TAG, "onPause");
    }
    @Override
    public void onStart(){
        super.onStart();
        Log.d(LOG_TAG, "onStart");
    }
    @Override
    public void onRestart(){
        super.onRestart();
        Log.d(LOG_TAG, "onRestart");
    }
    public void onResume(){
        super.onResume();
        Log.d(LOG_TAG, "onResume");
    }
    @Override
    public void onStop(){
        super.onStop();
        Log.d(LOG_TAG, "onStop");
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(LOG_TAG, "onDestroy");
    }

}